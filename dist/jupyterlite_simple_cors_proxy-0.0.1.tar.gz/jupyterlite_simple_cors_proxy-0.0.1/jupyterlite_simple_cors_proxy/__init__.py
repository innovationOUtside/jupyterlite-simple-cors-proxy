# File: jupyterlite_simple_cors_proxy/__init__.py
from .proxy import cors_proxy, ProxyResponse

__version__ = "0.1.0"
__all__ = ["cors_proxy", "ProxyResponse"]
